titre: Mon premier article
auteur: Bertil Chapuis
date: 2021-03-10
---
# Mon titre
## Mon sous-titre
Le contenu de mon article.
![Une image](./image.png)